bl_info = {
    "name": "Axis Align",
    "author": "Enoki",
    "version": (1, 0, 0),
    "blender": (2, 93, 0),
    "location": "View3D > Sidebar > Axis Align",
    "description": "Align an object's selected local axis to the view direction, or the active object while minimizing unwanted twisting.",
    "category": "Object"}

import bpy
from mathutils import Vector, Quaternion

# Axis vectors
AXES = {
    '+X': Vector((1, 0, 0)),
    '-X': Vector((-1, 0, 0)),
    '+Y': Vector((0, 1, 0)),
    '-Y': Vector((0, -1, 0)),
    '+Z': Vector((0, 0, 1)),
    '-Z': Vector((0, 0, -1))
}

WORLD_UP = Vector((0, 0, 1))
EPS = 1e-6

# Base class for shared properties and utilities
class AlignAxisBase:
    axis: bpy.props.EnumProperty(
        name="Target Axis",
        description="Local axis that will be aligned",
        items=[(k, k, "") for k in AXES],
        default='+Z'
    )

    @property
    def target_axis(self):
        return AXES[self.axis]

    def set_quat(self, obj, quat):
        obj.rotation_mode = 'QUATERNION'
        obj.rotation_quaternion = quat

# Align local axis to camera view direction
class AlignAxisToView(bpy.types.Operator, AlignAxisBase):
    bl_idname = "object.align_axis_to_view"
    bl_label = "Align Axis Towards Camera"
    bl_description = "Rotate selected objects so the chosen local axis points towards the current view"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.selected_objects and context.region_data

    def execute(self, context):
        view_dir = context.region_data.view_rotation @ Vector((0, 0, -1))
        for obj in context.selected_objects:
            self.set_quat(obj, self.target_axis.rotation_difference(view_dir))
        return {'FINISHED'}

# Align local axis to point at the active object
class AlignAxisToObject(bpy.types.Operator, AlignAxisBase):
    bl_idname = "object.align_axis_to_object"
    bl_label = "Align Axis Towards Active Object"
    bl_description = "Rotate selected objects so the chosen local axis points at the active object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 1 and context.active_object

    def execute(self, context):
        target = context.active_object.location
        for obj in context.selected_objects:
            if obj is context.active_object:
                continue
            direction = (target - obj.location).normalized()
            self.set_quat(obj, self.target_axis.rotation_difference(direction))
        return {'FINISHED'}

# Like AlignAxisToObject but removes unwanted twisting
class AlignAxisNoTwist(bpy.types.Operator, AlignAxisBase):
    bl_idname = "object.align_axis_no_twist"
    bl_label = "Align Axis (No Twist)"
    bl_description = "Rotate selected objects so the chosen local axis points at the active object, maintaining upright orientation to minimize twist"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return AlignAxisToObject.poll(context)

    def execute(self, context):
        target = context.active_object.location
        for obj in context.selected_objects:
            if obj is context.active_object:
                continue

            direction = (target - obj.location).normalized()
            base_quat = self.target_axis.rotation_difference(direction)

            # Attempt to maintain up orientation by minimizing twist
            up_vec = base_quat @ Vector((0, 1, 0))
            projected_up = up_vec - up_vec.project(direction)

            ref_up = WORLD_UP - WORLD_UP.project(direction)

            if projected_up.length > EPS and ref_up.length > EPS:
                projected_up.normalize()
                ref_up.normalize()
                angle = projected_up.angle(ref_up)
                sign = 1 if projected_up.cross(ref_up).dot(direction) >= 0 else -1
                twist_correction = Quaternion(direction, sign * angle)
                base_quat = twist_correction @ base_quat

            self.set_quat(obj, base_quat)

        return {'FINISHED'}

# UI Panel
class AlignAxisPanel(bpy.types.Panel):
    bl_label = "Axis Align"
    bl_idname = "VIEW3D_PT_align_axis"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Axis Align'

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "axis_to_view", text="Axis to Align")

        buttons = [
            ("object.align_axis_to_view", 'TRACKER', "Point axis to view direction"),
            ("object.align_axis_to_object", 'MESH_CUBE', "Point axis to active object"),
            ("object.align_axis_no_twist", 'ORIENTATION_GIMBAL', "Point axis to active object (No twist)")
        ]

        for op_id, icon, label in buttons:
            btn = layout.operator(op_id, text=label, icon=icon)
            btn.axis = context.scene.axis_to_view

# Register classes and properties
classes = (AlignAxisToView, AlignAxisToObject, AlignAxisNoTwist, AlignAxisPanel)

def register():
    from bpy.props import EnumProperty
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.axis_to_view = EnumProperty(
        name="Axis to Align",
        description="Select which local axis of the object should point toward the target",
        items=[(k, k, "") for k in AXES],
        default='+Z'
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.axis_to_view

if __name__ == "__main__":
    register()